package cooperation.q5;

public class BeanCoffee {

}
