package cooperation.q5;

public class Person {

}
