package cooperation.q5;

public class TakeTrans {

	public static void main(String[] args) {
		Person personKim = new Person("kim", 5000);
		Person personLee = new Person("Lee", 10000);
		
		Coffee coffee100 = new Coffee(100);
		personKim.takeCoffee(coffee100);
		personKim.showInfo();
		coffee100.showInfo();
		
		Coffee coffeegreen = new Coffee("2ȣ��");
		personKim.takeCoffee(coffeeGreen);
		personKim.showInfo();
		coffeeGreen.showInfo();

	}

}
